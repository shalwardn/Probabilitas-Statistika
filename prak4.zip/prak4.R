dbinom(3,15,0.1)
pbinom(2,15,0.1)
dbinom(0,15,0.1)
dbinom(1,15,0.1)
dbinom(2,15,0.1)
dbinom(6,15,0.1)+dbinom(7,15,0.1)
dpois(4,5)
dbinom(15,20,0.7)
dpois(3,2)

LATIHAN
dbinom(5, 15, 0.3)
