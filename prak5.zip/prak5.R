pnorm(189,184,5)
pnorm(199,184,5)-pnorm(174,184,5)

pnorm(120,173,34)
pcxp(5,1/7)-pcxp(3,1/7)
pexp(5,1/7)-pexp(3,1/7)
1-ppois(6,10)

1-0.1685
qnorm(0.8315,184,5)
pnorm(188.8,184,5)
pbinom(2,8,0.06)
1-pexp(8,1/7)
dpois(4,5)
