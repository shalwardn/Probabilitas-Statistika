data_nama = read.delim("clipboard")
View(data_nama)
mean(data_nama$Tinggi.Badan)
str(data_nama)